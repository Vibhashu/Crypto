import { createSlice } from '@reduxjs/toolkit';
import { initialCrypto } from './CryptoData';

const cryptoSlice = createSlice({
  name: 'crypto',
  initialState: initialCrypto,
  reducers: {
    updateAsset(state, action) {
      const index = state.findIndex(asset => asset.id === action.payload.id);
      if (index !== -1) {
        state[index] = { ...state[index], ...action.payload };
      }
    },
  },
});

export const { updateAsset } = cryptoSlice.actions;

export default cryptoSlice.reducer;
