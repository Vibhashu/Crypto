
import React from 'react';
import { useSelector } from 'react-redux';
import './CryptoTable.css';

const CryptoTable = () => {
  const data = useSelector(state=> state.crypto);

  return (
    <table className="crypto-table">
      <thead>
        <tr>
          <th>#</th><th>Logo</th><th>Name</th><th>Symbol</th><th>Price</th>
          <th>1h %</th><th>24h %</th><th>7d %</th><th>Market Cap</th>
          <th>24h Volume</th><th>Circulating</th><th>Max</th><th>7D Chart</th>
        </tr>
      </thead>
      <tbody>
        {data.map((asset, i) => (
          <tr key={asset.id}>
            <td>{i + 1}</td>    
            <td><img src={asset.logo} width="35" /></td>
            <td>{asset.name}</td>
            <td>{asset.symbol}</td>
            <td>${asset.price}</td>
            {['change1h', 'change24h', 'change7d'].map(field => (
              <td
                key={field}
                style={{ color: asset[field] >= 0 ? 'green' : 'red' }}
              >
                {asset[field]}%
              </td>
            ))}
            <td>${asset.marketCap.toLocaleString()}</td>
            <td>${asset.volume24h.toLocaleString()}</td>
            <td>{asset.circulatingSupply.toLocaleString()}</td>
            <td>{asset.maxSupply}</td>
            <td><img src={asset.chart} alt="chart"className='chart' width="50" /></td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default CryptoTable;
