import { updateAsset } from './CryptoSlice';


export const simulateUpdates = (dispatch, assets) => {
  setInterval(() => {
    const randomIndex = Math.floor(Math.random() * assets.length);
    const asset = assets[randomIndex];

    const randomChange = () => (Math.random() * 4 - 2).toFixed(2);

    dispatch(updateAsset({
      id: asset.id,
      price: (asset.price * (1 + randomChange() / 100)).toFixed(2),
      change1h: randomChange(),
      change24h: randomChange(),
      change7d: randomChange(),
      volume24h: asset.volume24h * (1 + Math.random() * 0.1),
    }));
  }, 5000);} 
