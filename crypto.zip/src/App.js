import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import CryptoTable from './CryptoTable';
import { simulateUpdates } from './DataSimulator';

function App() {
  const dispatch = useDispatch();
  const crypto = useSelector(state => state.crypto);

  useEffect(() => {
    simulateUpdates(dispatch, crypto);
  }, [dispatch, crypto]);

  return (
    <div className="App">
      <h1>📈 Crypto Tracker</h1>
      <CryptoTable />
    </div>
  );
}

export default App;
