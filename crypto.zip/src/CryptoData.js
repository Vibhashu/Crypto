import btc from './btc.png'
import eth from './eth.png'
import usdt from './usdt.png'
import bnb from './bnb.png'
import sql from './sql.png'

export const initialCrypto = [
    {
      id: 1,
      logo: 'https://www.svgrepo.com/show/303287/bitcoin-logo.svg',
      name: 'Bitcoin',
      symbol: 'BTC',
      price: 29350.75,
      change1h: -0.25,
      change24h: 1.18,
      change7d: 4.2,
      marketCap: 575000000000,
      volume24h: 25000000000,
      circulatingSupply: 19400000,
      maxSupply: 21000000,
      chart: btc
    },
    {
      id: 2,
      logo: 'https://www.svgrepo.com/show/349356/ethereum.svg',
      name: 'Ethereum',
      symbol: 'ETH',
      price: 1825.30,
      change1h: 0.12,
      change24h: -0.65,
      change7d: 3.9,
      marketCap: 220000000000,
      volume24h: 12000000000,
      circulatingSupply: 120000000,
      maxSupply: 500000000,
      chart: eth
    },
    {
      id: 3,
      logo: 'https://www.svgrepo.com/show/428645/tether-crypto-cryptocurrency.svg   ',
      name: 'Tether',
      symbol: 'USDT',
      price: 1.00,
      change1h: 0.01,
      change24h: 0.02,
      change7d: -0.01,
      marketCap: 88000000000,
      volume24h: 35000000000,
      circulatingSupply: 88000000000,
      maxSupply: 656546544545,
      chart: usdt
    },
    {
      id: 4,
      logo: 'https://www.svgrepo.com/show/331309/binance.svg',
      name: 'Binance Coin',
      symbol: 'BNB',
      price: 245.75,
      change1h: -0.45,
      change24h: 0.95,
      change7d: 2.1,
      marketCap: 37500000000,
      volume24h: 1200000000,
      circulatingSupply: 155000000,
      maxSupply: 200000000,
      chart: bnb
    },
    {
      id: 5,
      logo: 'https://logowik.com/content/uploads/images/solana1243.logowik.com.webp',
      name: 'Solana',
      symbol: 'SOL',
      price: 22.50,
      change1h: 0.32,
      change24h: -1.10,
      change7d: 5.4,
      marketCap: 9500000000,
      volume24h: 950000000,
      circulatingSupply: 420000000,
      maxSupply: 120006300,
      chart: sql
    }
  ];
  